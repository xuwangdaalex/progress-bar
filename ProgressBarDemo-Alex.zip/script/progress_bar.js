(function(){
	var app = angular.module('progressBarApp', []);
	var progressBarCtrl = function($scope){
		$scope.pbObj = [
			{
				"id": 1,
				"width": 25,
				"name": "Progress1" 
			},
			{
				"id": 2,
				"width": 50,
				"name": "Progress2"  
			},
			{
				"id": 3,
				"width": 75,
				"name": "Progress3"  
			},
		]
		$scope.activePb = $scope.pbObj[0];
		
		$scope.setWidth = function(w){
			for(var i = 0; i < $scope.pbObj.length; i++){
				if( $scope.pbObj[i].id == $scope.activePb.id){
					$scope.pbObj[i].width += w;
					if( $scope.pbObj[i].width < 0){
						$scope.pbObj[i].width = 0;
					}
					return;
				}
			}
		};
		
	}
	
	app.controller("progressBarCtrl", progressBarCtrl);
}());


